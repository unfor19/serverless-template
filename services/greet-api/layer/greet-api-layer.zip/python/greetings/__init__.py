# -*- coding: utf-8 -*-

"""Top-level package for Greetings."""

__author__ = """Chris Freeman"""
__email__ = 'chris.freeman.pdx@gmail.com'
__version__ = '0.1.0'
